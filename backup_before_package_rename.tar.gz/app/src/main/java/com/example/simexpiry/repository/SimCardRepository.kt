package com.example.simexpiry.repository

import androidx.lifecycle.LiveData
import com.example.simexpiry.data.SimCard
import com.example.simexpiry.data.SimCardDao

class SimCardRepository(private val simCardDao: SimCardDao) {
    val allSimCards: LiveData<List<SimCard>> = simCardDao.getAllSimCards()

    suspend fun insert(simCard: SimCard) = simCardDao.insert(simCard)
    suspend fun update(simCard: SimCard) = simCardDao.update(simCard)
    suspend fun delete(simCard: SimCard) = simCardDao.delete(simCard)
}

